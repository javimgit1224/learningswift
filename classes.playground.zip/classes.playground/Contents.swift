//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//when we put functions inside a class they become methods of a class
//much like c++ you can only acces var inside of functions scope

class Spaceship {
    var fuel_level:Int = 100
    
    func cruise() {
        //code to initiate cruising
        print(fuel_level)
    }
    func thrust() {
        //code to initiate rocket thrusters
        print(fuel_level)
    }
}
//create a constant Spaceship object
let my_ship:Spaceship = Spaceship()
//call the functions of the object
my_ship.cruise()
my_ship.thrust()
my_ship.fuel_level = 10
print(my_ship.fuel_level)


