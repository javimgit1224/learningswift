//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//functions in swift
//define
//a basic function
func sayHello() {
    print("hello")
}
//call
sayHello()

//function with parameters
func sayHelloTo(name:String){
    //hello <variable>
    print("hello \(name)")
}
sayHelloTo(name: "tom")

//function with two parameters
func sayHello2(name:String, age:Int){
    print("hello \(name) you are \(age) years old")
}
sayHello2(name: "tom", age: 22)

//function with return value
func addFourTo(x:Int) -> Int{
    let sum = x + 4
    return sum
}
var result = addFourTo(x: 10)
print(result)

