//: Playground - noun: a place where people can play

import UIKit

//addition
var a:Int = 20 + 5

//subtraction
var b:Int = 20 - 5

//multiplication
var c:Int = 20 * 5

//division
var d:Int = 20 / 5

//modulus
var e:Int = 20 % 2

//equations with variables
var f = ( a * b) + ( c / d)

//increment the variable
f = f + 1

//or
f += 1

//decrement the variable
f -= 1

//multiply the variable
f *= 2

//divide the variable
f /= 4

//additional operators

//absolute number
var g:Int = abs(-1)

//ceiling
var h = ceil(1.8)

//floor
var i = floor(1.4)

//square root
var j = sqrt(36)

//power
var k = pow(2, 4)

//print
print(k)

//this is how to make a constant
let con = "this is a constant"

//bool
var z:Bool = true
print(z)

