//: Playground - noun: a place where people can play
//you comment the same way you comment on c++

//import adds UIkit which is libraries that apple provides to create buttons
//whenever you start a new app project you will see the UIKit
import UIKit

var str = "Hello, playground"
//the right is showing what you did with that line
//var is a variable that stores
//str is the name of the variable
//= is assigning the text to the variable
print(str)
//print is actually printintg to the output
//declare a variable and assign a number to it
var a = 5
var b = 1
//you can add the variable in the print and it will print the sum
print(a+b)

//if statement
//works similar to c++
if (a+b > 8)
{
    print("true")
}
else
{
    print("false")
}
